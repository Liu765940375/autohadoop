--set spark.sql.shuffle.partitions=3150;
set spark.sql.shuffle.partitions=6520;
--set spark.sql.shuffle.partitions=3872;
--set spark.sql.shuffle.partitions=4224;
